// @author Jose Carlos Torro Belda

#define DEVICE_NAME "acumula"

int init_module(void);
void cleanup_module(void);
int llevamos(void);
void acumula(int i);
