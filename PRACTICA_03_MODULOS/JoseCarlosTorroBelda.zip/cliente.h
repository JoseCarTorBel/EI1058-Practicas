// @author Jose Carlos Torro Belda

#define DEVICE_NAME "cliente"

int init_module(void);
